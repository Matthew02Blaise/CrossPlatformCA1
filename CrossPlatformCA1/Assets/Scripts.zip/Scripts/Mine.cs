using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mine : MonoBehaviour
{
    public float speed = 2f;
    int direction = 1;

    Camera cam;
    float minY;
    float maxY;

    // Start is called before the first frame update
    void Start()
    {
        cam = Camera.main;

        float camHeight = cam.orthographicSize;
        float camCenterY = cam.transform.position.y;

        minY = camCenterY - camHeight;
        maxY = camCenterY + camHeight;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector2.up * direction * speed * Time.deltaTime);

        float clampedY = Mathf.Clamp(transform.position.y, minY, maxY);
        transform.position = new Vector3(transform.position.x, clampedY, transform.position.z);

        // Change direction when hitting bounds
        if (transform.position.y <= minY || transform.position.y >= maxY)
        {
            direction *= -1;
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        // Check if the collided object has a PlayerHealth component
        PlayerHealth player = other.GetComponent<PlayerHealth>();

        // If the player component exists, damage the player
        if (player != null)
        {
            player.TakeDamage(1);
            Destroy(gameObject);
        }
    }
}
